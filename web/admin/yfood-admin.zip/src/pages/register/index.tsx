import { AuthPage } from "@refinedev/mui";

export const Register = () => {
  return <AuthPage type="register" />;
};
